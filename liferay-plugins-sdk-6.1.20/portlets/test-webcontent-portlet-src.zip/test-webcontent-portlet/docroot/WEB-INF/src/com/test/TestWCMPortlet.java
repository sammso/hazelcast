package com.test;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.journal.model.JournalArticle;
import com.liferay.portlet.journal.model.JournalArticleDisplay;
import com.liferay.portlet.journal.service.JournalArticleLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

/**
 * Portlet implementation class TestWCMPortlet
 */
public class TestWCMPortlet extends MVCPortlet {
 
	public void testWCM(ActionRequest request, ActionResponse response){
		String wcid = request.getParameter("WCID");
		try {
			
			ThemeDisplay themeDisplay =
					(ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
			JournalArticle article = JournalArticleLocalServiceUtil.getArticle(themeDisplay.getScopeGroupId(),wcid);
			_log.info(article.getContent());
			_log.info("Is expired:" + article.isExpired());
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if(article.getExpirationDate()!=null){
				_log.info("ExpirationDate:"+ format.format(article.getExpirationDate())+ "current date:" + format.format(Calendar.getInstance().getTime()));
			}
			JournalArticleDisplay display = JournalArticleLocalServiceUtil.getArticleDisplay(themeDisplay.getScopeGroupId(), wcid, "view", themeDisplay.getLanguageId(), themeDisplay);
			_log.info(display.getContent());
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			_log.error("Error ",e);
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			_log.error("Error ",e);
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			_log.error("Error ",e);
			e.printStackTrace();
		}
	}

	
	private static Log _log = LogFactoryUtil.getLog(TestWCMPortlet.class);
}
